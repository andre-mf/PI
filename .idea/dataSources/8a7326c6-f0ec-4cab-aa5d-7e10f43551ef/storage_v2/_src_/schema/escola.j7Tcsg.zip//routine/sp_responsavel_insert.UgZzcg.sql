create procedure sp_responsavel_insert(IN pnome            varchar(50), IN ptelefone varchar(14),
                                       IN pendereco        varchar(200), IN pdata_nascimento datetime, IN psexo char)
  BEGIN

	INSERT INTO responsavel (nome, telefone, endereco, data_nascimento, sexo) VALUES (pnome, ptelefone, pendereco, pdata_nascimento, psexo);
    
    SELECT * FROM responsavel WHERE id_responsavel = LAST_INSERT_ID();
    
END;

