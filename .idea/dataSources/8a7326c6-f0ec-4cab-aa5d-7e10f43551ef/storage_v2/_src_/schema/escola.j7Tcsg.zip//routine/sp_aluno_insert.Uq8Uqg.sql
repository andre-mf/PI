create procedure sp_aluno_insert(IN pmatricula      varchar(10), IN pnome varchar(50), IN ptelefone varchar(14),
                                 IN pendereco       varchar(200), IN pdata_nascimento datetime, IN psexo char,
                                 IN pid_responsavel int, IN pid_curso int, IN pnota float)
  BEGIN

	INSERT INTO aluno (matricula, nome, telefone, endereco, data_nascimento, sexo, id_responsavel, id_curso, nota) VALUES (pmatricula, pnome, ptelefone, pendereco, pdata_nascimento, psexo, pid_responsavel, pid_curso, pnota);
    
    SELECT * FROM aluno WHERE id_aluno = LAST_INSERT_ID();
    
END;

