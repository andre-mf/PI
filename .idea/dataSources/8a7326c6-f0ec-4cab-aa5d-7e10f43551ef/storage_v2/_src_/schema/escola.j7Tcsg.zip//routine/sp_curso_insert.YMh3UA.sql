create procedure sp_curso_insert(IN pnome varchar(100))
  BEGIN

	INSERT INTO curso (nome) VALUES (pnome);
    
    SELECT * FROM curso WHERE id_curso = LAST_INSERT_ID();

END;

